from __future__ import absolute_import

from .legacy import (
    create_message, create_gzip_message,
    create_snappy_message, create_message_set,
    CODEC_NONE, CODEC_GZIP, CODEC_SNAPPY, ALL_CODECS,
    ATTRIBUTE_CODEC_MASK, KafkaProtocol,
)

from warnings import warn

warn("IPython.utils.jsonutil has moved to jupyter_client.jsonutil")

from jupyter_client.jsonutil import *

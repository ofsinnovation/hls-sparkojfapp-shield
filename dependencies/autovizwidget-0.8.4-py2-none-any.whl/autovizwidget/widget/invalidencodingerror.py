# Copyright (c) 2015  aggftw@gmail.com
# Distributed under the terms of the Modified BSD License.


class InvalidEncodingError(Exception):
    """An exception for encodings you can't work with."""


Provides findspark.init() to make pyspark importable as a regular library.



PyZMQ is the official Python binding for the ZeroMQ Messaging Library (http://www.zeromq.org).
See `the docs <https://pyzmq.readthedocs.io>`_ for more info.


